package com.example.evaluacion_2

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.app.Activity
// import android.media.MediaPlayer
import android.os.Bundle
import android.os.Handler
import android.view.*
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import android.os.CountDownTimer
import java.util.Collections.shuffle

//*** Paquetes para el manejo de controles


class Juego : Activity() {
    // vista
    var tablero: ArrayList<ImageButton> = arrayListOf<ImageButton>()
    var botonJuegoSalir: Button? = null
    var botonJuegoReiniciar: Button? = null
    var textoPuntuacion: TextView? = null
    var puntuacion: Int = 0
    var aciertos: Int = 0
    var imagenes: ArrayList<Int> = arrayListOf<Int>()
    var fondoPantalla : Int = 0

    //Variables del Juego de Memoria
    var arrayDesordenado: ArrayList<Int> = arrayListOf<Int>()
    var primero: ImageButton? = null
    var numeroPrimero = 0
    var numeroSegundo = 0
    var bloqueo = false
    val handler = Handler()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.juego)
        init()
    }

    private fun cargarTablero() {
        val  imb00:ImageButton = findViewById(R.id.boton00)
        val  imb01:ImageButton = findViewById(R.id.boton01)
        val  imb02:ImageButton = findViewById(R.id.boton02)
        val  imb03:ImageButton = findViewById(R.id.boton03)
        val  imb04:ImageButton = findViewById(R.id.boton10)
        val  imb05:ImageButton = findViewById(R.id.boton11)
        val  imb06:ImageButton = findViewById(R.id.boton12)
        val  imb07:ImageButton = findViewById(R.id.boton13)
        val  imb08:ImageButton = findViewById(R.id.boton20)
        val  imb09:ImageButton = findViewById(R.id.boton21)
        val  imb10:ImageButton = findViewById(R.id.boton22)
        val  imb11:ImageButton = findViewById(R.id.boton23)
        val  imb12:ImageButton = findViewById(R.id.boton30)
        val  imb13:ImageButton = findViewById(R.id.boton31)
        val  imb14:ImageButton = findViewById(R.id.boton32)
        val  imb15:ImageButton = findViewById(R.id.boton33)

        tablero.add(imb00)
        tablero.add(imb01)
        tablero.add(imb02)
        tablero.add(imb03)
        tablero.add(imb04)
        tablero.add(imb05)
        tablero.add(imb06)
        tablero.add(imb07)
        tablero.add(imb08)
        tablero.add(imb09)
        tablero.add(imb10)
        tablero.add(imb11)
        tablero.add(imb12)
        tablero.add(imb13)
        tablero.add(imb14)
        tablero.add(imb15)
    }

   // private fun mediaPlayer(){
     //   val mediaPlayer = MediaPlayer.create(this, R.raw.Amongus)
      //  mediaPlayer.start()

   // }

    private fun cargarBotones() {
        botonJuegoReiniciar = findViewById(R.id.botonJuegoReiniciar)
        botonJuegoSalir = findViewById(R.id.botonJuegoSalir)

        botonJuegoReiniciar?.setOnClickListener(View.OnClickListener {
                imagenes.clear()
                tablero.clear()
            arrayDesordenado.clear()
            aciertos = 0
            puntuacion=0
            textoPuntuacion!!.setText("Puntuacion: " + puntuacion)
                init() })
        botonJuegoSalir?.setOnClickListener  { finish() }


    }

    private fun cargarTexto() {
        textoPuntuacion = findViewById(R.id.texto_Puntuacion)
        textoPuntuacion?.setText("Puntuacion: $puntuacion")
    }

    private fun cargarImagenes() {
        imagenes.add(R.drawable.la0)
        imagenes.add(R.drawable.la1)
        imagenes.add(R.drawable.la2)
        imagenes.add(R.drawable.la3)
        imagenes.add(R.drawable.la4)
        imagenes.add(R.drawable.la5)
        imagenes.add(R.drawable.la6)
        imagenes.add(R.drawable.la7)

        fondoPantalla = R.drawable.fondo
    }


    private fun barajar(longitud: Int): ArrayList<Int> {
        val result = ArrayList<Int>()
        for (i in 0 until longitud * 2) {
            result.add(i % longitud)
        }
        shuffle(result)
        //System.out.println(Arrays.toString(result.toArray()));
        return result
    }

    private fun comprobar(i: Int, j: ImageButton){
        if(primero == null){
            primero = j
            primero!!.scaleType = ImageView.ScaleType.CENTER_CROP
            primero!!.setImageResource(imagenes[arrayDesordenado.get(i)])
            primero!!.isEnabled = false
            numeroPrimero = arrayDesordenado.get(i)
        } else {
            bloqueo = true
            j.scaleType = ImageView.ScaleType.CENTER_CROP
            j.setImageResource(imagenes[arrayDesordenado.get(i)])
            j.isEnabled = false
            numeroSegundo = arrayDesordenado.get(i)

            if(numeroPrimero == numeroSegundo){
                primero = null
                bloqueo = false
                aciertos++
                puntuacion++
                textoPuntuacion!!.setText("Puntuacion: $puntuacion")

                if (aciertos == imagenes.size){
                    Toast.makeText(this, "Felicitaciones!! Lo Lograste!", Toast.LENGTH_LONG).show()
                }
            } else {

                object: CountDownTimer(1000, 1){
                    override fun onTick(p0: Long) {
                    }
                    override fun onFinish() {
                        primero!!.scaleType = ImageView.ScaleType.CENTER_CROP
                        primero!!.setImageResource(fondoPantalla)
                        primero!!.isEnabled = true
                        j.scaleType = ImageView.ScaleType.CENTER_CROP
                        j.setImageResource(fondoPantalla)
                        j.isEnabled = true
                        bloqueo = false
                        primero = null
                        puntuacion--
                        textoPuntuacion!!.setText("Puntuacion: $puntuacion")
                    }
                }.start()
            }
        }
    }

    private fun init() {
        cargarTablero()
        cargarBotones()
        cargarTexto()
        cargarImagenes()
        arrayDesordenado = barajar(imagenes.size)

        object: CountDownTimer(2000, 1){
            override fun onTick(p0: Long) {
                for(i: Int in 0 until tablero.size){
                    tablero[i].scaleType = ImageView.ScaleType.CENTER_CROP
                    tablero[i].setImageResource(imagenes[arrayDesordenado.get(i)])
                }
            }
            override fun onFinish() {
                for(i: Int in 0 until tablero.size){
                    tablero[i].scaleType = ImageView.ScaleType.CENTER_CROP
                    tablero[i].setImageResource(fondoPantalla)
                }
            }
        }.start()

        for(i: Int in 0 until tablero.size){
            val j: Int = i
            tablero[i].isEnabled
            tablero[i].setOnClickListener{
                if(!bloqueo){
                    comprobar(j,tablero[j])
                }
            }
        }


        for (i in tablero.indices) {
            tablero[i]!!.scaleType = ImageView.ScaleType.CENTER_CROP
            tablero[i]!!.setImageResource(imagenes[arrayDesordenado.get(i)])
            //tablero[i].setImageResource(fondo);
        }
        handler.postDelayed({
            for (i in tablero.indices) {
                tablero[i]!!.scaleType = ImageView.ScaleType.CENTER_CROP
                //tablero[i].setImageResource(imagenes[arrayDesordenado.get(i)]);
                tablero[i]!!.setImageResource(fondoPantalla)
            }
        }, 1000)
        for (i in tablero.indices) {
            tablero[i]!!.isEnabled = true
            tablero[i]!!.setOnClickListener { if (!bloqueo) comprobar(i, tablero[i]) }
        }
    }
}


