package com.example.evaluacion_2
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.content.ContentValues

class ScoreDatabaseHelper(context: Context) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        private const val DATABASE_NAME = "Records.db"
        private const val DATABASE_VERSION = 1

        // Definir el nombre de la tabla y los nombres de las columnas
        private const val TABLE_NAME = "Records"
        private const val COLUMN_ID = "id"
        private const val COLUMN_PLAYER_NAME = "Nombre de Jugador"
        private const val COLUMN_SCORE = "Puntaje"
    }

    override fun onCreate(db: SQLiteDatabase) {
        // Crear la tabla
        val createTableSQL = "CREATE TABLE $TABLE_NAME " +
                "($COLUMN_ID INTEGER PRIMARY KEY AUTOINCREMENT," +
                "$COLUMN_PLAYER_NAME TEXT, " +
                "$COLUMN_SCORE INTEGER);"
        db.execSQL(createTableSQL)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // Actualizar la base de datos si es necesario
        db.execSQL("DROP TABLE IF EXISTS $TABLE_NAME")
        onCreate(db)
}

}